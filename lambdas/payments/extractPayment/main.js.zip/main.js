'use strict'

const AWS = require('aws-sdk')


exports.handler = async () => {
    return {
        statusCode:200,
        header: {
            'Content-type' : 'application/json'
        },
        body: 'Working'
    }
}
